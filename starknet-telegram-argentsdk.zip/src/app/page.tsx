
import ExchangePage from "./exchange/page"

export default function Home() {

  return (
    <>
      <ExchangePage />
    </>
  );
}
