export default function Layout({ children }: { children: React.ReactNode }) {
    // Return only children, bypassing the default layout
    return <>        
            
             {children}
          </>
  }
  